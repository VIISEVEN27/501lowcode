import {createRouter, createWebHistory, RouteRecordRaw} from "vue-router"
import Index from "@/views/Index.vue"

const routes: Array<RouteRecordRaw> = [
    {
        path: "/",
        name: "Index",
        component: Index,
    },
]

const router = createRouter({
    routes,
    history: createWebHistory(import.meta.env.BASE_URL),
})

export default router
